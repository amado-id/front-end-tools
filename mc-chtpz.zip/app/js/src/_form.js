document.addEventListener('DOMContentLoaded', () => {
	if (document.querySelector('.am-pay-form')) {
		const form = new Form(document.querySelectorAll('.am-pay-form'), {
			focusValidate: true,
			classes: {
				empty: 'am-empty',
				error: 'am-error',
				correct: 'am-correct'
			},
			fields: [
				{
					fieldName: 'service',
					realTimeRegExp: 'text',
					realTime: true,
					required: true
				},
				{
					fieldName: 'name',
					realTimeRegExp: 'text',
					realTime: true,
					required: true
				},
				{
					fieldName: 'family',
					realTimeRegExp: 'text',
					realTime: true,
					required: true
				},
				{
					fieldName: 'otch',
					realTimeRegExp: 'text',
					realTime: true,
					required: true
				},
				{
					fieldName: 'phone',
					realTimeRegExp: 'phone',
					realTime: true,
					required: true,
					regExp: 'phone',
					mask: '+7 (***) ***-**-**'
				},
			]
		});

		form.on('submit', function(e) {
			if (!document.querySelector('.am-pay-form__checkbox').checked) {
				e.preventDefault();
				document.querySelector('.am-pay-form__accept').classList.add('am-pay-form__accept_error');
			}
		});

		document.querySelectorAll('.am-pay-form__input').forEach(item => {
			item.addEventListener('input', function() {
				if (this.value) {
					this.nextElementSibling.style.display = 'none';
				} else {
					this.nextElementSibling.style.display = 'block';
				}
			});
		});

		const scroll = new PerfectScrollbar(document.querySelector('.am-pay-form__list'), {
			useBothWheelAxes: true,
		});

		document.querySelector('.am-pay-form__button').addEventListener('click', function() {
			listOpen();
		});

		document.querySelector('.am-pay-form__list').addEventListener('click', function(e) {
			if (e.target.classList.contains('am-pay-form__item')) {
				this.parentElement.querySelector('.am-pay-form__input').value = e.target.innerHTML;
				this.parentElement.querySelector('.am-pay-form__input').classList.remove('am-empty');
				this.parentElement.querySelector('.am-pay-form__placeholder').style.display = 'none';
				listOpen();
			}
		});

		document.body.addEventListener('click', function(e) {
			if (document.querySelector('.am-pay-form__button').classList.contains('am-pay-form__button_open') && !e.target.closest('.am-pay-form__wrap_list')) {
				listOpen();
			}
		});

		function listOpen() {
			const button = document.querySelector('.am-pay-form__button');
			if (button.classList.contains('am-pay-form__button_open')) {
				button.classList.remove('am-pay-form__button_open');
				button.nextElementSibling.classList.remove('am-pay-form__list_open');
			} else {
				button.classList.add('am-pay-form__button_open');
				button.nextElementSibling.classList.add('am-pay-form__list_open');
			}
		}
	}
});